﻿using System;

namespace My1024
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("开始!");
            Console.WriteLine("==========================================");
            new Game().Play();
            Console.Read();
            Console.WriteLine("==========================================");
            Console.WriteLine("结束!");
        }
    }
}
