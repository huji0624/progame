﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace My1024
{
    public class GameModle
    {
        /// <summary>
        /// 0登陆 -1登陆失败 1请准备 2准备好了 3游戏信息 4玩家行动 5游戏结束
        /// </summary>
        public int Msgtype { get; set; }
        public int GameID { get; set; }

        public string Token { get; set; } = "";

        public int RoundID { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
        public int Wid { get; set; }
        public int Hei { get; set; }

        public Tilemap[][] Tilemap { get; set; }

    }

    public class NoMoveModel
    {
        public string Name { get; set; }
        public string Locations { get; set; }
        public int Num { get; set; }
    }


    public class Tilemap
    {
        public int Gold { get; set; }
        public List<Player> Players { get; set; }
    }

    public class Player
    {
        public string Name { get; set; }
        public int Gold { get; set; }
    }

    public class TilemapList
    {
        public int Gold { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
    }

    public class PlayersLocationsModle
    {

        public string Locations { get; set; }
        public int X { get; set; }
        public int Y { get; set; }

        public int Gold { get; set; }

        /// <summary>
        /// 最大金币的位置
        /// </summary>
        public string MaxLocations { get; set; }
        /// <summary>
        /// 最大金币的数量
        /// </summary>
        public int MaxGold { get; set; }

        public List<AllGoldModle> AllGold { get; set; } = new List<AllGoldModle>();
    }

    public class AllGoldModle
    {
        public int Gold { get; set; }
        public string Name { get; set; }
        /// <summary>
        /// 最大金币的位置
        /// </summary>
        public string MaxLocations { get; set; }
        /// <summary>
        /// 最大金币的数量
        /// </summary>
        public int MaxGold { get; set; }
    }

    public class MyGoldModle
    {
        /// <summary>
        /// 当前位置
        /// </summary>
        public string MaxLocations { get; set; }
        /// <summary>
        /// 不计算逻辑的情况下最大金币的数量
        /// </summary>
        public int MaxGold { get; set; }

        public int X { get; set; }
        public int Y { get; set; }

        /// <summary>
        /// 格子里金币的数量
        /// </summary>
        public int Gold { get; set; }
        /// <summary>
        /// 判断逻辑能拿到的金币数
        /// </summary>
        public int JudgeMaxGold { get; set; }

        public int OtherNum { get; set; }

    }

    public class WinsModel
    {
        public string Name { get; set; }
        public int Gold { get; set; }
    }

}
