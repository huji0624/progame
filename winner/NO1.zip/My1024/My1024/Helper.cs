﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace My1024
{
    public static class Helper
    {

        public static IQueryable<T> WhereIf<T>(this IQueryable<T> query, bool condition, Expression<Func<T, bool>> predicate)
        {
            return condition ? query.Where(predicate) : query;
        }

        public static IQueryable<T> WhereIf<T>(this IQueryable<T> query, bool condition, Expression<Func<T, int, bool>> predicate)
        {
            return condition ? query.Where(predicate) : query;
        }

        public static IEnumerable<T> WhereIf<T>(this IEnumerable<T> query, bool condition, Func<T, bool> predicate)
        {
            return condition ? query.Where(predicate) : query;
        }
        /// <summary>
        /// object转换为Json
        /// </summary>
        /// <param name="obj">object</param>
        /// <returns></returns>
        public static string ToJson(this object obj)
        {
            var timeConverter = new IsoDateTimeConverter { DateTimeFormat = "yyyy-MM-dd HH:mm:ss" };
            return JsonConvert.SerializeObject(obj, timeConverter);
        }
        /// <summary>
        /// object转换为Json(自定义日期格式)
        /// </summary>
        /// <param name="obj">object</param>
        /// <param name="datetimeformats">日期格式</param>
        /// <returns></returns>
        public static string ToJson(this object obj, string datetimeformats)
        {
            var timeConverter = new IsoDateTimeConverter { DateTimeFormat = datetimeformats };
            return JsonConvert.SerializeObject(obj, timeConverter);
        }
        /// <summary>
        /// Json转换为object
        /// </summary>
        /// <typeparam name="T">类型</typeparam>
        /// <param name="Json">Json</param>
        /// <returns></returns>
        public static T ToObject<T>(this string Json)
        {
            return Json == null ? default(T) : JsonConvert.DeserializeObject<T>(Json);
        }
        /// <summary>
        /// Json转换为List
        /// </summary>
        /// <typeparam name="T">类型</typeparam>
        /// <param name="Json">Json</param>
        /// <returns></returns>
        public static List<T> ToList<T>(this string Json)
        {
            return Json == null ? null : JsonConvert.DeserializeObject<List<T>>(Json);
        }
        /// <summary>
        /// Json转换为DataTable
        /// </summary>
        /// <param name="Json">Json</param>
        /// <returns></returns>
        public static DataTable ToTable(this string Json)
        {
            return Json == null ? null : JsonConvert.DeserializeObject<DataTable>(Json);
        }
        /// <summary>
        /// Json转换为JObject
        /// </summary>
        /// <param name="Json">Json</param>
        /// <returns></returns>
        public static JObject ToJObject(this string Json)
        {
            return Json == null ? JObject.Parse("{}") : JObject.Parse(Json.Replace("&nbsp;", ""));
        }

        /// <summary>
        /// 数组转换为逗号分隔的字符串
        /// </summary>
        /// <param name="arr"></param>
        /// <returns></returns>
        public static string ArrToString(this string[] arr)
        {
            var Data = string.Join(",", arr);
            return Data;
        }
        /// <summary>
        /// 集合转换为逗号分隔的字符串
        /// </summary>
        /// <param name="arr"></param>
        /// <returns></returns>
        public static string ListToString(this List<string> arr)
        {
            var Data = string.Join(",", arr);
            return Data;
        }
        /// <summary>
        /// 集合转换为逗号分隔的字符串
        /// </summary>
        /// <param name="arr"></param>
        /// <returns></returns>
        public static string ListToString(this IEnumerable<string> arr)
        {
            var Data = string.Join(",", arr);
            return Data;
        }
        /// <summary>
        /// 逗号分隔的字符串转换为集合
        /// </summary>
        /// <param name="arr"></param>
        /// <returns></returns>
        public static List<string> StringToList(this string str)
        {
            List<string> Data = new List<string>();
            if (string.IsNullOrWhiteSpace(str))
            {
                return Data;
            }
            if (!str.Contains(","))
            {
                Data.Add(str);
                return Data;
            }
            Data = new List<string>(str.Split(','));
            return Data;
        }
        /// <summary>
        /// 逗号分隔的字符串转换为集合
        /// </summary>
        /// <param name="arr"></param>
        /// <returns></returns>
        public static List<Guid> StringToListGuid(this string str)
        {
            List<Guid> Data = new List<Guid>();
            if (string.IsNullOrWhiteSpace(str))
            {
                return Data;
            }
            if (!str.Contains(","))
            {
                Data.Add(Guid.Parse(str));
                return Data;
            }
            var _str = str.Split(',');
            for (var i = 0; i < _str.Length; i++)
            {
                Data.Add(Guid.Parse(_str[i]));
            }

            return Data;
        }

        public static string FirstUpper(string str)
        {
            if (!string.IsNullOrEmpty(str))
            {
                str = str.ToLower();
                return str.Substring(0, 1).ToUpper() + str.Substring(1);
            }
            return str;
        }
       
    }
}
