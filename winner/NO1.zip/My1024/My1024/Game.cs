﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Websocket.Client;
using Websocket.Client.Models;

namespace My1024
{
    /// <summary>
    /// 代码使用了大量的重复变量，一切都是为了空间换时间
    /// </summary>
    public class Game
    {
        //定义Socket对象
        public static WebsocketClient clientSocket;
        //创建接收消息的线程
        public Thread threadReceive;

        public static string Url = "ws://pgame.51wnl-cq.com:8881/ws";
        //public static string Url = "ws://192.168.2.38:8881/ws";

        public static int Num = 1;
        public static string Token = "9cElBpoVFolPKeotT7UnBsNxIoDO2wUO";
        public static string Name = "(H·ω·H)";
        public static List<string> RobotName = new List<string>() { "RandRobot" };

        public List<NoMoveModel> NoMoveData = new List<NoMoveModel>();

        public void Play()
        {
            PrintMsg("游戏开始!");

            var exitEvent = new ManualResetEvent(false);
            var url = new Uri(Url);

            using (clientSocket = new WebsocketClient(url))
            {
                clientSocket.ReconnectTimeout = TimeSpan.FromHours(1);

                clientSocket.ReconnectionHappened.Subscribe(info =>
                    ReconnectionHappened(info)
                );

                clientSocket.MessageReceived.Subscribe(msg =>
                    PlayThis(msg.ToString())
                );

                clientSocket.Start();

                Login();

                exitEvent.WaitOne();
            }

        }






        /// <summary>
        /// 发送数据
        /// </summary>
        /// <param name="Msg"></param>
        private void Send(string Msg)
        {
            try
            {
                byte[] buffer = new byte[20000];
                buffer = Encoding.Default.GetBytes(Msg);
                clientSocket.Send(buffer);
                PrintMsg($"发送参数{Msg}");
            }
            catch (Exception ex)
            {
                PrintMsg(ex.Message);
            }

        }


        /// <summary>
        /// 登录
        /// </summary>
        private void Login()
        {
            var Data = new
            {
                msgtype = 0,
                token = Token
            };
            Send(Data.ToJson());
            Thread.Sleep(1000);
        }


        /// <summary>
        /// 处理数据
        /// </summary>
        /// <param name="Data"></param>
        private void PlayThis(string Str)
        {
            try
            {
                Stopwatch watch = new Stopwatch();
                watch.Start();
                PrintMsg($"得到回调数据{Str}");
                var Data = Str.ToObject<GameModle>();
                switch (Data.Msgtype)
                {
                    case 0:
                        PrintMsg("登录成功！");
                        break;
                    case -1:
                        Login();
                        break;
                    case 1:
                        Send(new { msgtype = 2, token = Token }.ToJson());
                        NoMoveData = new List<NoMoveModel>();
                        break;
                    case 3:
                        Send(Go(Data));
                        break;
                    case 5:
                        PrintMsg("本局结束！");
                        NoMoveData = new List<NoMoveModel>();
                        Log.Info("", "");
                        break;
                    default:
                        break;
                }
                watch.Stop();
                PrintMsg($"第{Num}次收到服务器数据，处理耗时：{watch.Elapsed.TotalMilliseconds.ToString("#0.00")}毫秒");
                Num++;
            }
            catch (Exception ex)
            {

                PrintMsg(ex.Message);
            }

        }

        /// <summary>
        /// 处理游戏逻辑
        /// </summary>
        /// <param name="Data"></param>
        private string Go(GameModle Data)
        {
            Log.Info("", Data.ToJson());
            var Old_X = Data.X;
            var Old_Y = Data.Y;
            var New_X = Data.X;
            var New_Y = Data.Y;
            int MyGold = 0;
            //获取所有玩家的位置
            Dictionary<string, PlayersLocationsModle> PlayersLocations = new Dictionary<string, PlayersLocationsModle>();
            List<TilemapList> tilemapList = new List<TilemapList>();
            List<WinsModel> Wins = new List<WinsModel>();
            var Tilemap = Data.Tilemap;
            for (int j = 0; j < Tilemap.GetLength(0); j++)
            {
                for (int i = 0; i < Tilemap[j].GetLength(0); i++)
                {
                    tilemapList.Add(new TilemapList()
                    {
                        Gold = Tilemap[j][i].Gold,
                        X = i,
                        Y = j,
                    });
                    if (Tilemap[j][i].Players != null)
                    {
                        foreach (var p in Tilemap[j][i].Players)
                        {
                            if (RobotName.Contains(p.Name)) continue;
                            Wins.Add(new WinsModel()
                            {
                                Name = p.Name,
                                Gold = p.Gold
                            });

                            if (p.Name == Name)
                            {
                                MyGold = p.Gold;
                            }
                            //PrintMsg($"{p.Name}在{i},{j}   金币{p.Gold}");
                            PlayersLocations.Add(p.Name, new PlayersLocationsModle() { X = i, Y = j, Locations = $"{i},{j}", Gold = p.Gold, MaxLocations = $"{i},{j}", MaxGold = 0 });


                            if (NoMoveData.Where(t => t.Name == p.Name).Count() > 0)
                            {
                                var _noMoveData = NoMoveData.Where(t => t.Name == p.Name).FirstOrDefault();
                                if (_noMoveData.Locations == $"{i},{j}")
                                {
                                    _noMoveData.Num++;
                                }
                                else
                                {
                                    _noMoveData.Locations = $"{i},{j}";
                                    _noMoveData.Num = 0;
                                }
                            }
                            else
                            {
                                NoMoveData.Add(new NoMoveModel()
                                {
                                    Name = p.Name,
                                    Locations = $"{i},{j}",
                                    Num = 0
                                });
                            }
                        }
                    }
                }
            }

            List<MyGoldModle> _myGoldModles = new List<MyGoldModle>();

            //计算最大收益
            foreach (var _tilemapList in tilemapList)
            {
                foreach (var key in PlayersLocations.Keys)
                {
                    var _p = PlayersLocations[key];
                    int TheyCount = (int)(GetTheyCount(_p.X, _p.Y, _tilemapList.X, _tilemapList.Y) * 1.5);
                    var G = _tilemapList.Gold - TheyCount;
                    if (G > _p.MaxGold && _p.Gold >= TheyCount)
                    {
                        _p.MaxGold = G;
                        _p.MaxLocations = $"{_tilemapList.X},{ _tilemapList.Y}";
                        //PrintMsg($"{key}的最佳位置在{_tilemapList.X},{_tilemapList.Y}   金币{G}  步数{TheyCount}");
                    }
                    PlayersLocations[key].AllGold.Add(new AllGoldModle()
                    {
                        MaxGold = G,
                        MaxLocations = $"{_tilemapList.X},{ _tilemapList.Y}",
                        Name = key,
                        Gold = _p.Gold
                    }
                    );

                    //如果是自己的，就记录下来
                    if (key == Name && _p.Gold >= TheyCount)
                    {
                        _myGoldModles.Add(new MyGoldModle()
                        {
                            MaxGold = G,
                            MaxLocations = $"{_tilemapList.X},{ _tilemapList.Y}",
                            X = _tilemapList.X,
                            Y = _tilemapList.Y,
                            Gold = _tilemapList.Gold,
                            JudgeMaxGold = _tilemapList.Gold
                        });

                    }
                }

            }


            Old_X = PlayersLocations[Name].X;
            Old_Y = PlayersLocations[Name].Y;

            PlayersLocations.Remove(Name);

            //选择每个敌人的前10位置
            List<AllGoldModle> MaxLocationsList = new List<AllGoldModle>();

            foreach (var key in PlayersLocations.Keys)
            {
                var _noMoveData = NoMoveData.Where(t => t.Name == key).FirstOrDefault();
                if (_noMoveData != null && _noMoveData.Num > 3)
                {
                    MaxLocationsList.Add(new AllGoldModle()
                    {
                        Gold = PlayersLocations[key].Gold,
                        Name = key,
                        MaxLocations = _noMoveData.Locations,
                        MaxGold = 0
                    });

                }
                else
                {
                    var _maxLocations = PlayersLocations[key].AllGold;
                    foreach (var _m in _maxLocations.Where(t => t.MaxGold > 0).OrderByDescending(t => t.MaxGold).Take(10))
                    {
                        MaxLocationsList.Add(_m);
                    }
                }

            }

            //_myGoldModles = _myGoldModles.Where(t => t.MaxGold > 0).OrderByDescending(t => t.MaxGold).ToList();
            //PrintMsg($"前5的最佳位置在{_myGoldModles.Take(5).ToJson()}");


            foreach (var _m in _myGoldModles)
            {
                var _maxLocationsList = MaxLocationsList.Select(t => t.MaxLocations);
                var a = MaxLocationsList.Where(t => _maxLocationsList.Contains(_m.MaxLocations)).ToList();
                _m.OtherNum = a.Count();
                if (a.Count() == 0)
                {
                    if (_m.Gold == -4)
                    {
                        _m.JudgeMaxGold = (int)((MyGold * 0.4));
                    }
                    else
                    {
                        _m.JudgeMaxGold = _m.MaxGold;
                    }

                }
                else
                {
                    if (_m.Gold == -4)
                    {
                        var g = (int)((MyGold * 0.4));
                        _m.JudgeMaxGold = GetDivideGold(a, MyGold + g + _m.MaxGold);
                    }
                    else if (_m.Gold > 0 && _m.Gold % 5 == 0)
                    {
                        var g = (a.Sum(t => t.Gold) + MyGold) / (a.Count() + 1);
                        _m.JudgeMaxGold = GetDivideGold(a, MyGold + g + _m.MaxGold);
                    }
                    else if (_m.Gold == 7 || _m.Gold == 11)
                    {
                        var g = 0;
                        _m.JudgeMaxGold = GetDivideGold(a, MyGold + g + _m.MaxGold);
                    }
                    else if (_m.Gold == 8)
                    {
                        var g = _m.Gold / (a.Count() + 1);
                        _m.JudgeMaxGold = GetDivideGold(a, MyGold + g + _m.MaxGold);
                    }
                    else
                    {
                        var g = _m.Gold;
                        _m.JudgeMaxGold = GetDivideGold(a, MyGold + g + _m.MaxGold);
                    }
                }

            }


            var BestGoldModlesQ = _myGoldModles
                                    .WhereIf(MaxLocationsList.Select(t => t.Gold).Distinct().Where(t => t > MyGold).Count() < 3, t => t.OtherNum == 0)
                                    .OrderByDescending(t => t.JudgeMaxGold);

            var BestGoldModles = BestGoldModlesQ.Count() > 2 ? BestGoldModlesQ.Skip(1).ToList().FirstOrDefault() : BestGoldModlesQ.FirstOrDefault();



            New_X = BestGoldModles != null ? BestGoldModles.X : Old_X;
            New_Y = BestGoldModles != null ? BestGoldModles.Y : Old_Y;
            //碰瓷
            AllGoldModle _maxOne = null;

            if (MaxLocationsList.Select(t => t.Gold).Distinct().Where(t => t > MyGold).Count() > 3)
            {
                foreach (var _maxLocationsList in MaxLocationsList.OrderByDescending(t => t.Gold).ThenBy(t => t.MaxGold))
                {
                    if (MaxLocationsList.Where(t => t.MaxLocations == _maxLocationsList.MaxLocations).Count() == 1)
                    {
                        _maxOne = _maxLocationsList;
                        break;
                    }
                }
            }


            var MaxJudgeMaxGold = BestGoldModles == null ? 0 : BestGoldModles.JudgeMaxGold;

            if (_maxOne != null && _myGoldModles.Select(t => t.MaxLocations).Contains(_maxOne.MaxLocations) && _maxOne.Gold > MyGold && (_maxOne.Gold / 4) > MaxJudgeMaxGold)
            {
                New_X = int.Parse(_maxOne.MaxLocations.Split(',')[0]);
                New_Y = int.Parse(_maxOne.MaxLocations.Split(',')[1]);
                PrintMsg($"碰瓷:{_maxOne.MaxLocations}，敌人金币：{_maxOne.Gold}，我的金币：{MyGold}");
            }

            PrintMsg($"{Wins.OrderByDescending(t => t.Gold).ToJson()}");
            return new
            {
                msgtype = 4,
                token = Token,
                x = New_X,
                y = New_Y,
                RoundID = Data.RoundID
            }.ToJson();

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="OldX">原位置</param>
        /// <param name="OldY">原位置</param>
        /// <param name="X">要去的位置</param>
        /// <param name="Y">要去的位置</param>
        /// <returns></returns>
        private int GetTheyCount(int OldX, int OldY, int X, int Y)
        {
            var XCount = OldX >= X ? OldX - X : X - OldX;
            var YCount = OldY >= Y ? OldY - Y : Y - OldY;
            return XCount + YCount;
        }

        private void PrintMsg(string Str, bool IsLog4 = true)
        {
            try
            {
                if (Str.Contains(Name))
                {
                    Console.WriteLine("");
                    var s = Str.Split(Name);
                    Console.Write($"{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:ffff")}   ");
                    for (int i = 0; i < s.Length; i++)
                    {
                        Console.Write($"{s[i]}");
                        if (i != s.Length - 1)
                        {
                            WriteColor($"{Name}", ConsoleColor.Red);
                        }
                    }
                    Console.WriteLine("");
                }
                else
                {
                    Console.WriteLine($"{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:ffff")}   {Str}");
                }

                if (IsLog4)
                {
                    //Log.Info("", Str);
                }
            }
            catch (Exception ex)
            {

            }

        }

        private void ReconnectionHappened(ReconnectionInfo info)
        {
            PrintMsg($"连接状态, type: {info.Type}");
            if (info.Type != ReconnectionType.Initial)
            {
                Login();
            }
        }

        private int GetDivideGold(List<AllGoldModle> a, int MyGold)
        {
            var MinGold = a.Min(t => t.Gold);
            if (MinGold > MyGold)
            {
                return MinGold / 4 / (a.Count() + 1);
            }
            else
            {
                return (MyGold / 4) * -1;
            }
        }


        static void WriteColorLine(string str, ConsoleColor color)
        {
            ConsoleColor currentForeColor = Console.ForegroundColor;
            Console.ForegroundColor = color;
            Console.WriteLine(str);
            Console.ForegroundColor = currentForeColor;
        }

        static void WriteColor(string str, ConsoleColor color)
        {
            ConsoleColor currentForeColor = Console.ForegroundColor;
            Console.ForegroundColor = color;
            Console.Write(str);
            Console.ForegroundColor = currentForeColor;
        }

    }



}
